# ARTIFICIAL INTELLIGENCE INTERNSHIP
> Here I have completed 3 months training and 1 allocated project MLP Face Recognition.

## Task-1 - MLP Face Recognition
## Description -
* The Multi-Layer Perceptron (MLP) Face Recognition System is an innovative project that leverages the power of artificial neural networks to identify and recognize faces.
   
* The project aims to develop a robust and efficient face recognition system using the MLP model, a type of feedforward artificial neural network.

### Software Requirements -
Jupyter Notebook.
